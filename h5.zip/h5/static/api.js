/**
 * API列表
 */
"use strict";
const URL = 'https://www.qifusenlin.com/';
// const  URL = 'https://function.natapp4.cc/'
export default {
	VIP_CANCEL_PAY:URL + "forest/weapp/cancelPartnerPay",
	
	GET_ADDRESS:URL + "api/cities/getAddress",
	
	PARTNER_MSG: URL + "forest/partner/getPartner",
	/**
	 * 开通合伙人-微信消息模板推送
	 */
	PARTNER_TEMPLATE_MSG: URL + "forest/wechat/partner/sendMessageTemplate",
	/**
	 * 订单-微信消息模板推送
	 */
	ORDER_TEMPLATE_MSG: URL + "forest/wechat/order/sendMessageTemplate",
	/**
	 * 授权
	 */
	USER_INFO: URL + "api/wechat/userMsg",
	/**
	 * 绑定银行卡
	 */
	BANK_BIND: URL + "api/user/card/save",
	/**
	 * 取消绑定银行卡
	 */
	UNBANK_BIND: URL + "api/user/card/delete",
	/**
	 * 获取银行卡
	 */
	GET_BANK: URL + "api/user/card/info",
	/**
	 * 获取父级分类下的所有子分类
	 */
	CHILDREN_LIST: URL + "api/category/detail",
	/**
	 * 获取热销服务
	 */
	SELL_WELL_LIST: URL + "api/category/sellWellList",
	/**
	 * test 测试生成二维码
	 */
	QR_CODE: URL + "api/qr/create",
	/**
	 * 更新个人信息
	 */
	ME_INFO_UPDATE: URL + "api/me/info/modifyUserInfo",
	/**
	 * 获取个人信息
	 */
	ME_INFO_DETAIL: URL + "api/me/info/detail",
	/**
	 * 实名认证
	 */
	/**
	 * 城市
	 */
	CITY_LISET: URL + "api/cities/queryList",
	REAL_NAME: URL + "api/me/info/realName",
	/**
	 * 支付密码
	 */
	PAY_PAS: URL + "api/me/info/resetPayPwd",
	/**
	 * 我的首席金卡
	 */
	ME_JCARD: URL + "api/me/info/jcard/detail",
	/**
	 * 获取标签资源
	 */
	TAGS_LIST: URL + "api/tags/list",
	/**
	 * 新增标签资源
	 */
	TAGS_ADD: URL + "api/tags/add",
	/**
	 * 绑定用户资源
	 */
	USER_TAGS_ADD: "/api/user/tags/add",
	/**
	 * 圈子列表接口
	 */
	CIRCEL_LIST: URL + "api/user/list",
	/**
	 * 圈子详情
	 */
	CIRCEL_DETAIL: URL + "api/user/detail",
	/**
	 * 查看微信或手机接口
	 */
	USER_CHECK: URL + "api/user/check",
	/**
	 * 获取搜索圈子接口
	 */
	CIRCEL_SEARCH: URL + "api/user/type/list",
	/**
	 * 获取指定类型的人
	 */
	USER_LIST: URL + "api/user/list",
	/**
	 * 统计开通会员的人数
	 */
	USER_COUNT: URL + "api/user/count",
	/**
	 * 获取服务详情
	 */
	SERVICE_DETAIL: URL + "forest/service/info",
	/**
	 * 修改服务浏览量
	 */
	SERVICE_ADD_BROWSECOUNT: "/api/shop/service/addBrowseCount",
	/**
	 * 关键字搜索接口
	 */
	SEARCH_LIST: URL + "api/shop/service/search",
	/**
	 * 获取服务商下的服务
	 */
	PROVIDER_SERVICE: URL + "forest/service/list",
	/**
	 * 获取服务商详情
	 */
	PROVIDER_SERVICE_DETAIL: URL + "api/shop/detail",
	/**
	 * 申请成为服务商
	 */
	SHOP_SAVE: URL + "api/shop/save",

	/**
	 * 获取分类下的所有服务
	 */
	CATEGORY_SERVICE: URL + "api/shop/service/serviceListByCategory",
	/**
	 * 关键字搜索服务
	 */
	SERVICE_SEARCH: URL + "api/shop/service/search",
	/**
	 * 服务订单
	 */
	ORDER_LIST: URL + "forest/order/queryUserAllOrder/",
	/**
	 * 关闭订单
	 */
	ORDER_CLOSE: URL + "api/order/withdrawalOfOrder",
	/**
	 * 生成服务订单
	 */
	CREATE_SERVICE_ORDER: URL + "api/service/order",
	/**
	 * 支付订单接口
	 */
	PAY_WEAPP_ORDERPAY: URL + "forest/weapp/orderPay",

	/**
	 * 提现
	 */
	REMOVE_MONEY: URL + "api/removeMoney",

	/**
	 * 获取订单详情
	 */
	ORDER_DETAIL: URL + "api/order/detail",
	/**
	 * 获取所有分类
	 */
	CATEGORY_LIST: URL + "api/category/list",
	/**
	 * 获取分类的子分类
	 */
	CETEGORY_CHILD_LIST: URL + "api/category/detail",
	/**
	 * 获取热销服务分类
	 */
	CATEGORY_SELL_WELL_LIST: URL + "api/category/sellWellList",
	/**
	 * 我的优惠券
	 */
	COUPON: URL + "api/user/coupon/queryUserCoupon",
	/**
	 * 匹配满足条件的优惠券
	 */
	USER_COUPON: URL + "api/user/coupon/queryUserCoupon",
	/**
	 * 获取服务详情
	 */
	UPLOAD_FILE: URL + "api/upload/upload",
	/**
	 * 获取推荐列表
	 */
	RECOMMENDRECORD_LIST: URL + "api/recommendrecord/list",
	/**
	 * 获取热销服务
	 */
	HOT_SERVICE: URL + "api/shop/service/list",
	BANK_CHEAK: URL + "api/user/card/getUserCardBank",
	/**
	 * 推荐金卡接口
	 */
	APPLAY_CARD: URL + "api/weapp/payJcard",
	/**
	 * 分享之后
	 */
	API_SHARE_RED: URL + "api/wishes/sender/send",
	/**
	 * 查看红包详情
	 */
	API_WATCH_BAG: URL + "api/wishes/sender/detail",
	/**
	 * 获得红包
	 */
	API_GET_BAG: URL + "api/wishes/receiver/receive",
	/**
	 * 统计红包
	 */
	API_REG_COUNT: "/api/wishes/count",
	/**
	 * banner
	 */
	API_BANNER_LIST: URL + "api/banner/list",
	/**
	 * Home
	 */
	API_HOME: URL + "forest/service/list",
	/**
	 * 我的钱包
	 */
	MY_BAG: URL + "api/me/info/myBag",
	/**
	 * 首席头条
	 */
	LIST_LINE_TIP: URL + "api/headlines/list",

	OPEN_CARD_NUM: URL + "api/me/info/addJCardForInviteCode",
	/**
	 * 关闭订单
	 */
	ORDER_DELETE: URL + "api/order/close",
	/**
	 * 添加发票
	 */
	ADD_INVOICE: URL + "api/invoice/save",
	/**
	 * 删除发票
	 */
	CLOSE_INVOICE: URL + "api/invoice/delete",
	/**
	 * 聊天历史
	 */
	HISTORY_CHAT: URL + "api/chatroom/queryHistoryMessage",
	/**
	 * 未读的信息
	 */
	MESSEAGE: URL + "api/chatroom/chatList",
	CHEACK_MESSAGE: URL + "api/wechat/ws/login",
	/**
	 * 店铺代金券
	 */
	SHOP_COUPON: URL + "api/coupon/queryCouponByProvider",
	/**
	 * 添加店铺优惠券
	 */
	AND_COUPON: URL + "api/user/coupon/addUserCoupon",
	/**
	 * 查询已领取过的优惠券
	 */
	USERS_COUPONED: URL + "api/coupon/queryExistsCouponByUser",
	/**
	 * 商标分页
	 */
	TRADEMARK: URL + "api/trademark/list",
	/**
	 * 商标查询
	 */
	ADD_TRADEMARK: URL + "api/trademark/queryListByParentId",
	/**
	 * 经营范围
	 */
	QUERY_RANGE: URL + "api/business/scope/queryByKeyword",
	/**
	 * 一键注册公司
	 */
	SAVE_COMPANY: URL + "api/registry/company/detail/save",
	/**
	 * 经营范围所有种类的
	 */
	QUERY_RANGE_MIDDEL: URL + "api/business/scope/queryParentBusinessScope",
	/**
	 * 根据中类查询小类
	 */
	QUERY_RANGE_SMALL: URL + "api/business/scope/queryChildrenByParentId",
	/**
	 * 保存url 身份证
	 */
	IDCARD_UPLOAD: URL + "api/registry/company/detail/upload",
	/**
	 * 查询已开发票
	 */
	INVOICE_OPENED: URL + "api/invoice/queryInvoiceList",
	/**
	 * 查询未开发票
	 */
	INVOICE_OPENING: URL + "api/invoice/queryHasNotInvoice",
	/**
	 * 生成二维码
	 */
	QR_CREATE: URL + "api/wechat/getWxQrCodeUrl",
	/**
	 * 店铺合伙人列表接口
	 */
	SHOP_PERSON_LIST: URL + "forest/partner/",
	/**
	 * 服务商详情接口
	 */
	SHOP_PROVIER_INTRO: URL + "forest/provider/info/",
	/**
	 * 企业森林 我的钱包接口
	 */

	MY_BAG_HISTORY: URL + "forest/partner/moneybag",
	/**
	 * 交易列表记录 
	 */
	BUY_HISTORY: URL + "forest/transaction/record/list",
	/**
	 * 总赏金
	 */
	ACOUNT_NUM: URL + "forest/energy/queryTotalReward",
	/**
	 * 会费列表
	 */
	JOIN_ACOUNT: URL + "forest/energy/queryMoneyReward/",
	/**
	 * 交易额列表
	 */
	ORDER_ACOUNT: URL + "forest/energy/queryDealReward/",
	/**
	 * 获取收货接口
	 */
	QUERY_ADDRESS: URL + "forest/user/address/list",
	/**
	 * 获取所有的父级分类
	 */
	QUERY_PARENT_CATEGORY: URL + "api/category/queryParentCategoryByType",
	/**
	 * 我的银行卡信息
	 */
	QUERY_BANK_LIST: URL + "api/user/card/getUserCardBankList",
	/**
	 * 收货地址
	 */
	SAVE_ADDRESSS: URL + "forest/user/address/save",
	/**
	 * 查询
	 */
	QUERY_ADDRESS: URL + "forest/user/address/list",
	/**
	 * 编辑收货地址
	 */
	EDIT_ADDRESS: URL + "forest/user/address/update",
	/**
	 * 删除收货地址
	 */
	DELETE_ADDRESS: URL + "forest/user/address/delete",
	/**
	 * 我发展的团队
	 */
	DEVELOP_TEAM: URL + "forest/partner/",
	/**
	 * 合伙人的服务商列表
	 */
	PARTNER_PROVIDER_LIST: URL + "forest/partner/provider/queryProviderByParId",
	/**
	 * 能量未领取接口
	 */
	ENERY_NO_LIST: URL + "forest/energy/waitEnergy",
	/**
	 * 能量领取接口
	 */
	ENERY_AND: URL + "forest/energy/addEnergy",
	/**
	 * 能量任务列表
	 */
	ENERY_LIST: URL + "forest/assignment/list",
	/**
	 * 申请退款
	 */
	REFUND_ORDER: URL + "forest/refund/save",
	/**
	 * 支付 
	 */
	PAY_PARTNER: URL + "forest/weapp/partnerPay",
	/**
	 * 推荐店铺
	 */
	TJ_SHOP: URL + "forest/partner/provider/queryRecShop",
	/**
	 * 我挂靠的店铺
	 */
	SAVE_SHOPS: URL + "forest/partner/provider/save",
	/**
	 * 我服务的店铺
	 */
	SHOPS_SERVICE_LIST: URL + "forest/partner/provider/queryProviderByParId",
	/**
	 * 服务详情页面
	 */
	ORDER_DETAIL_FORSET: URL + "forest/order/queryOrderDetail",
	/**
	 * 合伙人海报生成
	 */
	PERSON_VIP: URL + "/api/wechat/dailyForwardingForEnergy",
	PARTNER_SERIVCE_LIST: URL + "forest/partner/service/list",
	PARTNER_SERIVCE_SAVE: URL + "forest/partner/service/save",
	/**
	 * 合伙人资料查询
	 */
	PARTNER_INFO: URL + "forest/partner/info/",
	/**
	 * 合伙人调整价格
	 * 
	 */
	PARTNER_PRICE: URL + "forest/poster/service/updatePriceAndSave",
	/**
	 * 提现接口
	 */
	CASH_GET: URL + "forest/cash/out/cashableBalance",
	CASH_SAVE: URL + "forest/cash/out/cashOutBalance",
	
	/**
	 * 订单重新发起支付
	 */
	ONE_MORE_PAYED: URL + "forest/weapp/repaymentOfOrder",
	/**
	 * 分类
	 */
	GET_CATEGORY: URL + "api/category/queryParentCategories",
	DELETE_ORDER: URL + "forest/order/delete"
};
